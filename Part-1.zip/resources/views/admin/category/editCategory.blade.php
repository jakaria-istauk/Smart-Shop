@extends('admin.master')

@section('content')
<hr/>
<div class="row">
    <div class="col-lg-12">
        <div class="well">

            {!! Form::open( [ 'url'=>'category/update', 'method'=>'POST', 'name'=>'editCategoryForm' ] ) !!}
            <div class="form-group">
                <label for="sname">Category Name:</label>
                <input type="text" class="form-control" id="sname" value="{{ $categoryById->categoryName }}" name="categoryName"  >
                <input type="hidden" class="form-control" id="sname" value="{{ $categoryById->id }}" name="id"  >
                <span class="text-danger">{{ $errors->has('categoryName') ? $errors->first('categoryName') : '' }}</span>
            </div>
            <div class="form-group">
                <label for="Description">Category Description: </label>
                <textarea style="height: 200px;" type="text" class="form-control" id="address" name="categoryDescription" rows="8">{{ $categoryById->categoryDescription }}</textarea>
                <span class="text-danger">{{ $errors->has('categoryDescription') ? $errors->first('categoryDescription') : '' }}</span>
            </div>
            <div class="form-group">
                <label for="sel1">Publication Status:</label>
                <select class="form-control" name="publicationStatus" id="sel1">
                    <option>----Select Publication Status----</option>
                    <option value="1">Published</option>
                    <option value="0">Unpublished</option>
                </select>
            </div> 
            <input type="submit" name="btn" class="btn btn-primary" value="Update Category Info">
            {!! Form::close() !!}
        </div>
    </div>
</div>

<script>
    document.forms['editCategoryForm'].elements['publicationStatus'].value={{  $categoryById->publicationStatus }}
</script>

@endsection
