@extends('admin.master')

@section('content')
<hr/>
<div class="row">
    <div class="col-lg-12">
        <div class="well">

            {!! Form::open( [ 'url'=>'manufacturer/update', 'method'=>'POST', 'name'=>'editmanufactureForm' ] ) !!}
            <div class="form-group">
                <label for="sname">Category Name:</label>
                <input type="text" class="form-control" id="sname" value="{{ $manufacturerById->manufactureName }}" name="manufactureName"  >
                <input type="hidden" class="form-control" id="sname" value="{{ $manufacturerById->id }}" name="id"  >
                <span class="text-danger">{{ $errors->has('manufactureName') ? $errors->first('manufactureName') : '' }}</span>
            </div>
            <div class="form-group">
                <label for="Description">Category Description: </label>
                <textarea style="height: 200px;" type="text" class="form-control" id="address" name="manufactureDescription" rows="8">{{ $manufacturerById->manufactureDescription }}</textarea>
                <span class="text-danger">{{ $errors->has('manufactureDescription') ? $errors->first('manufactureDescription') : '' }}</span>
            </div>
            <div class="form-group">
                <label for="sel1">Publication Status:</label>
                <select class="form-control" name="publicationStatus" id="sel1">
                    <option>----Select Publication Status----</option>
                    <option value="1">Published</option>
                    <option value="0">Unpublished</option>
                </select>
            </div> 
            <input type="submit" name="btn" class="btn btn-primary" value="Update Category Info">
            {!! Form::close() !!}
        </div>
    </div>
</div>

<script>
    document.forms['editmanufactureForm'].elements['publicationStatus'].value={{  $manufacturerById->publicationStatus }}
</script>

@endsection
