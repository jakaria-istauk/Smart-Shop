@extends('admin.master')

@section('content')
<hr/>
<div class="row">
    <div class="col-lg-12">
        <h2 class="text-success text-center">{{Session::get('message')}}</h2>
        <div class="well">

            {!! Form::open( [ 'url'=>'manufacturer/save', 'method'=>'POST' ] ) !!}
            <div class="form-group">
                <label for="sname">Manufacture Name:</label>
                <input type="text" class="form-control" id="sname" name="manufactureName"  >
                <span class="text-danger">{{ $errors->has('manufactureName') ? $errors->first('manufactureName') : '' }}</span>
            </div>
            <div class="form-group">
                <label for="Description">Manufacture Description: </label>
                <textarea style="height: 200px;" type="text" class="form-control" id="address" name="manufactureDescription" rows="8"></textarea>
                <span class="text-danger">{{ $errors->has('manufactureDescription') ? $errors->first('manufactureDescription') : '' }}</span>
            </div>
            <div class="form-group">
                <label for="sel1">Publication Status:</label>
                <select class="form-control" name="publicationStatus" id="sel1">
                    <option>----Select Publication Status----</option>
                    <option value="1">Published</option>
                    <option value="0">Unpublished</option>
                </select>
            </div> 
            <input type="submit" name="btn" class="btn btn-primary" value="Save Manufacturer Info">
            {!! Form::close() !!}
        </div>
    </div>
</div>
@endsection