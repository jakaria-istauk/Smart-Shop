@extends('admin.master')
@section('content')
<hr/>
<div class="row">
    <div class="col-lg-12">
        <h2 class="text-success text-center">{{Session::get('message')}}</h2>
        <div class="panel panel-default">
            <div class="panel-heading">
                DataTables Advanced Tables
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Category Name</th>
                            <th>Manufacturer Name</th>
                            <th>Product Price</th>
                            <th>Product Quantity</th>
                            <th>Publication Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($products as $product)
                        <tr>
                            <td>{{ $product->productName}}</td>
                            <td>{{ $product->categoryName}}</td>
                            <td>{{ $product->manufactureName}}</td>
                            <td>TK. {{ $product->productPrice}}/-</td>
                            <td>{{ $product->productQuantity}}</td>
                            <td>{{ $product->publicationStatus == 1 ? 'Published' : "Unpublished"}}</td>
                            <td>
                                <a href="{{ url('/product/view/'.$product->id) }}" class="btn btn-info" title="View Details">
                                    <i class="glyphicon glyphicon-info-sign"></i> 
                                </a>
                                <a href="{{ url('/product/edit/'.$product->id) }}" class="btn btn-success" title="Edit Product">
                                    <i class="glyphicon glyphicon-edit"></i> 
                                </a>
                                <a href="{{ url('/product/delete/'.$product->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete this');" title="Delet Product">
                                    <i class="glyphicon glyphicon-trash"></i> 
                                </a>
                            </td>
                        </tr>
                         @endforeach
                    </tbody>
                </table>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>

@endsection
