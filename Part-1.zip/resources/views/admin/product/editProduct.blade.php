@extends('admin.master')

@section('content')
<hr/>
<div class="row">
    <div class="col-lg-12">
        <h2 class="text-success text-center">{{Session::get('message')}}</h2>
        <div class="well">

            {!! Form::open( [ 'url'=>'product/update', 'method'=>'POST', 'enctype'=>'multipart/form-data', 'name'=>'editProductForm' ] ) !!}
            <div class="form-group">
                <label for="sname">Product Name:</label>
                <input type="text" class="form-control" id="sname" name="productName"  value="{{ $productById->productName }}">
                <input type="hidden" class="form-control" id="sname" name="productId"  value="{{ $productById->id }}">
                <span class="text-danger">{{ $errors->has('productName') ? $errors->first('productName') : '' }}</span>
            </div>
            <div class="form-group">
                <label for="sel1">Category name:</label>
                <select class="form-control" name="categoryId" id="sel1">
                    <option>----Select Category Name----</option>
                    @foreach($categories as $category)
                    <option value="{{$category->id}}">{{$category->categoryName}}</option>
                    @endforeach
                </select>
            </div> 
            
            <div class="form-group">
                <label for="sel1">Manufacturer name:</label>
                <select class="form-control" name="manufacturerId" id="sel1">
                    <option>----Select Manufacturer Name----</option>
                    @foreach($manufacturers as $manufacturer)
                    <option value="{{$manufacturer->id}}">{{$manufacturer->manufactureName}}</option>
                    @endforeach
                </select>
            </div> 
            
            <div class="form-group">
                <label for="sname">Product Price:</label>
                <input type="number" class="form-control" id="sname" name="productPrice"   value="{{ $productById->productPrice }}" >
                <span class="text-danger">{{ $errors->has('productPrice') ? $errors->first('productPrice') : '' }}</span>
            </div>
            
            <div class="form-group">
                <label for="sname">Product Quantity:</label>
                <input type="number" class="form-control" id="sname" name="productQuantity"    value="{{ $productById->productQuantity }}">
                <span class="text-danger">{{ $errors->has('productQuantity') ? $errors->first('productQuantity') : '' }}</span>
            </div>
            
            <div class="form-group">
                <label for="Description">Product Short Description: </label>
                <textarea style="" type="text" class="form-control" id="address" name="productShortDescription" rows="4">{{ $productById->productShortDescription }}</textarea>
                <span class="text-danger">{{ $errors->has('productShortDescription') ? $errors->first('productShortDescription') : '' }}</span>
            </div>
            
            <div class="form-group">
                <label for="Description">Product Long Description: </label>
                <textarea style="" type="text" class="form-control" id="address" name="productLongDescription" rows="8">{{ $productById->productLongDescription }}</textarea>
                <span class="text-danger">{{ $errors->has('productLongDescription') ? $errors->first('productLongDescription') : '' }}</span>
            </div>
            
            <div class="form-group">
                <label for="sname">Product Image:</label>
                <input type="file" id="sname" name="productImage" accept="image/*" >
                <img src="{{ asset($productById->productImage) }}" alt="{{ $productById->productName }}" width="300px">
            </div>
            
            <div class="form-group">
                <label for="sel1">Publication Status:</label>
                <select class="form-control" name="publicationStatus" id="sel1">
                    <option>----Select Publication Status----</option>
                    <option value="1">Published</option>
                    <option value="0">Unpublished</option>
                </select>
            </div> 
            <input type="submit" name="btn" class="btn btn-primary btn-lg btn-block" value="Update Product Info">
            {!! Form::close() !!}
        </div>
    </div>
</div>

<script>
    document.forms['editProductForm'].elements['categoryId'].value={{  $productById->categoryId }}
    document.forms['editProductForm'].elements['manufacturerId'].value={{  $productById->manufacturerId }}
    document.forms['editProductForm'].elements['publicationStatus'].value={{  $productById->publicationStatus }}
</script>

@endsection
