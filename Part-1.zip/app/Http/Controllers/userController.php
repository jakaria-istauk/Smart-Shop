<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class userController extends Controller
{
    public function managerUser(){
        $users = User::all();
        return view('admin.user.manageUser', ['users'=>$users]);
    }
}
