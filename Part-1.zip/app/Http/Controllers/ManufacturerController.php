<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Manufacturer;

class ManufacturerController extends Controller
{
    public function creatManufacture(){
        return view('admin.manufacturer.creatManufacturer');
    }
    
    public function storeManufacture(Request $request){
        $this->validate($request, [
            'manufactureName' => 'required',
            'manufactureDescription' => 'required',
        ]);
        //return $request->all();
        $manufacturer = new Manufacturer();
        $manufacturer->manufactureName = $request->manufactureName;
        $manufacturer->manufactureDescription = $request->manufactureDescription;
        $manufacturer->publicationStatus = $request->publicationStatus;
        $manufacturer->save();
        return redirect('/manufacturer/add')->with('message', 'Manufacturer Info saved Successfully');
    }
    
    public function manageManufacture(){
        $manufacturer = Manufacturer::all();
        return view('admin.manufacturer.manageManufacturer', ['manufacturers' => $manufacturer]);
    }
    
    public function editManufacture($id){
        $manufacturerById = Manufacturer::where('id', $id)->first();
        return view('admin.manufacturer.editManufacturer', ['manufacturerById' => $manufacturerById]);
    }
    
    public function updateManufacture(Request $request){
        //dd($request->all());
        $this->validate($request, [
            'manufactureName' => 'required',
            'manufactureDescription' => 'required',
        ]);
        
        $manufacturer = Manufacturer::find($request->id);
        $manufacturer->manufactureName = $request->manufactureName;
        $manufacturer->manufactureDescription = $request->manufactureDescription;
        $manufacturer->publicationStatus = $request->publicationStatus;
        $manufacturer->save();
        return redirect('/manufacturer/manage')->with('message', 'Manufacturer Info Updated Successfully');
    }
    
    public function deleteManufacture($id){
        $manufacturer = Manufacturer::find($id);
        $manufacturer->delete();
        return redirect('/manufacturer/manage')->with('message', 'Manufacturer Info Deleted Successfully');
    }
}
