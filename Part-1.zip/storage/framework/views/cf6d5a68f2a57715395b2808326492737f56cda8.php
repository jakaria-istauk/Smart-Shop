<?php $__env->startSection('content'); ?>
<hr/>
<div class="row">
    <div class="col-lg-12">
        <h2 class="text-success text-center"><?php echo e(Session::get('message')); ?></h2>
        <div class="panel panel-default">
            <div class="panel-heading">
                DataTables Advanced Tables
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th>Category Name</th>
                            <th>Category Description</th>
                            <th>Publication Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->categoryName); ?></td>
                            <td><?php echo e($category->categoryDescription); ?></td>
                            <td class="center"><?php echo e($category->publicationStatus == 1 ? 'Published' : "Unpublished"); ?></td>
                            <td>
                                <a href="<?php echo e(url('/category/edit/'.$category->id)); ?>" class="btn btn-success">
                                    <i class="glyphicon glyphicon-edit"></i> 
                                </a>
                                <a href="<?php echo e(url('/category/delete/'.$category->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete this');">
                                    <i class="glyphicon glyphicon-trash"></i> 
                                </a>
                            </td>
                        </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>