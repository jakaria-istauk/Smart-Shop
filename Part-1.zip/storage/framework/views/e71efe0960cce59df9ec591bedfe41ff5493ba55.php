<?php $__env->startSection('content'); ?>
<hr/>
<div class="row">
    <div class="col-lg-12">
        <h2 class="text-success text-center"><?php echo e(Session::get('message')); ?></h2>
        <div class="well">

            <?php echo Form::open( [ 'url'=>'category/save', 'method'=>'POST' ] ); ?>

            <div class="form-group">
                <label for="sname">Category Name:</label>
                <input type="text" class="form-control" id="sname" name="categoryName"  >
                <span class="text-danger"><?php echo e($errors->has('categoryName') ? $errors->first('categoryName') : ''); ?></span>
            </div>
            <div class="form-group">
                <label for="Description">Category Description: </label>
                <textarea style="height: 200px;" type="text" class="form-control" id="address" name="categoryDescription" rows="8"></textarea>
                <span class="text-danger"><?php echo e($errors->has('categoryDescription') ? $errors->first('categoryDescription') : ''); ?></span>
            </div>
            <div class="form-group">
                <label for="sel1">Publication Status:</label>
                <select class="form-control" name="publicationStatus" id="sel1">
                    <option>----Select Publication Status----</option>
                    <option value="1">Published</option>
                    <option value="0">Unpublished</option>
                </select>
            </div> 
            <input type="submit" name="btn" class="btn btn-primary" value="Save Category Info">
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>