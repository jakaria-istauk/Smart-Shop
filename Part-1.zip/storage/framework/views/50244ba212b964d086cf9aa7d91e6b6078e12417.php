<h1>Hello Jakaria from Demo Page</h1>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($v_data['name']); ?><br/>
    <?php echo e($v_data['departmetn']); ?><br/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

