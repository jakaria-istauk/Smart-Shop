<?php $__env->startSection('content'); ?>
<hr/>
<div class="row">
    <div class="col-lg-12">
        <h2 class="text-success text-center"><?php echo e(Session::get('message')); ?></h2>
        <div class="well">

            <?php echo Form::open( [ 'url'=>'product/update', 'method'=>'POST', 'enctype'=>'multipart/form-data', 'name'=>'editProductForm' ] ); ?>

            <div class="form-group">
                <label for="sname">Product Name:</label>
                <input type="text" class="form-control" id="sname" name="productName"  value="<?php echo e($productById->productName); ?>">
                <input type="hidden" class="form-control" id="sname" name="productId"  value="<?php echo e($productById->id); ?>">
                <span class="text-danger"><?php echo e($errors->has('productName') ? $errors->first('productName') : ''); ?></span>
            </div>
            <div class="form-group">
                <label for="sel1">Category name:</label>
                <select class="form-control" name="categoryId" id="sel1">
                    <option>----Select Category Name----</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->categoryName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div> 
            
            <div class="form-group">
                <label for="sel1">Manufacturer name:</label>
                <select class="form-control" name="manufacturerId" id="sel1">
                    <option>----Select Manufacturer Name----</option>
                    <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->manufactureName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div> 
            
            <div class="form-group">
                <label for="sname">Product Price:</label>
                <input type="number" class="form-control" id="sname" name="productPrice"   value="<?php echo e($productById->productPrice); ?>" >
                <span class="text-danger"><?php echo e($errors->has('productPrice') ? $errors->first('productPrice') : ''); ?></span>
            </div>
            
            <div class="form-group">
                <label for="sname">Product Quantity:</label>
                <input type="number" class="form-control" id="sname" name="productQuantity"    value="<?php echo e($productById->productQuantity); ?>">
                <span class="text-danger"><?php echo e($errors->has('productQuantity') ? $errors->first('productQuantity') : ''); ?></span>
            </div>
            
            <div class="form-group">
                <label for="Description">Product Short Description: </label>
                <textarea style="" type="text" class="form-control" id="address" name="productShortDescription" rows="4"><?php echo e($productById->productShortDescription); ?></textarea>
                <span class="text-danger"><?php echo e($errors->has('productShortDescription') ? $errors->first('productShortDescription') : ''); ?></span>
            </div>
            
            <div class="form-group">
                <label for="Description">Product Long Description: </label>
                <textarea style="" type="text" class="form-control" id="address" name="productLongDescription" rows="8"><?php echo e($productById->productLongDescription); ?></textarea>
                <span class="text-danger"><?php echo e($errors->has('productLongDescription') ? $errors->first('productLongDescription') : ''); ?></span>
            </div>
            
            <div class="form-group">
                <label for="sname">Product Image:</label>
                <input type="file" id="sname" name="productImage" accept="image/*" >
                <img src="<?php echo e(asset($productById->productImage)); ?>" alt="<?php echo e($productById->productName); ?>" width="300px">
            </div>
            
            <div class="form-group">
                <label for="sel1">Publication Status:</label>
                <select class="form-control" name="publicationStatus" id="sel1">
                    <option>----Select Publication Status----</option>
                    <option value="1">Published</option>
                    <option value="0">Unpublished</option>
                </select>
            </div> 
            <input type="submit" name="btn" class="btn btn-primary btn-lg btn-block" value="Update Product Info">
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<script>
    document.forms['editProductForm'].elements['categoryId'].value=<?php echo e($productById->categoryId); ?>

    document.forms['editProductForm'].elements['manufacturerId'].value=<?php echo e($productById->manufacturerId); ?>

    document.forms['editProductForm'].elements['publicationStatus'].value=<?php echo e($productById->publicationStatus); ?>

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>